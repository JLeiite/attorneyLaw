import './../styles/header.scss'
import { List } from 'phosphor-react'
import { useState } from 'react';

export function Header() {
    // Estados para controlar a visibilidade de cada elemento pelo ID
    const [elementVisibility, setElementVisibility] = useState({
        menu: 'hidden'
        });
          
        const toggleVisibility = (elementId) => {
            setElementVisibility((prevState) => ({
              ...prevState,
              [elementId]: prevState[elementId] === 'visible' ? 'hidden' : 'visible',
            }));
        };

    return(
        <>
            <nav className="navbar sticky-top navbar-expand-lg">
                <div className="container-fluid">
                    <a href="#" className='float-start'> <img src='https://uploaddeimagens.com.br/images/004/705/426/full/logo.png?1704651199' alt="Logo" /></a>
                    <ul className="navbar-nav mb-2 mb-lg-0 d-none d-lg-block">
                        <li className="nav-item floatEnd">
                            <a className="nav-link" href="#">
                                <button type="button" className="btn btn-outline-light">Contact us</button>
                            </a>
                        </li>
                    </ul>
                    <button className="btn btn-outline-light d-lg-none" type="button" onClick={() => toggleVisibility('menu')}>
                        <List size={24}/>
                    </button>
                    <div className="col-12" style={{
                                visibility: elementVisibility.menu,
                                maxHeight: elementVisibility.menu === 'hidden' ? 0 : 'none',
                                overflow: 'hidden',
                                transition: 'max-height 0.5s ease-in-out',
                                }}>
                        <ul className="navbar-nav mb-2 mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link d-lg-none" href="#">Contact us</a>
                            </li>
                            <li className="nav-item d-lg-none">
                                <a className="nav-link" href="#aboutUs">About us</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </>
    )
}